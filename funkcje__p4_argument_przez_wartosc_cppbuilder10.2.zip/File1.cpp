#include <iostream>
using namespace std;
#include <conio.h>
#pragma hdrstop
#pragma argsused

#ifdef _WIN32
#include <tchar.h>
#else
  typedef char _TCHAR;
  #define _tmain main
#endif

#include <stdio.h>

int zwieksz_wartosc(int liczba_kopia)
{
	liczba_kopia = liczba_kopia++;
    return liczba_kopia;
}

int _tmain(int argc, _TCHAR* argv[])
{
    int liczba = 99;

	cout << zwieksz_wartosc(liczba) << endl;

    getch(); // stopujemy aplikacj�, aplikacja czeka na jaki� klawisz

	return 0;
}

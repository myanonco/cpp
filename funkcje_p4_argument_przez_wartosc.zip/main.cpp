#include <iostream>
using namespace std;

int zwieksz_wartosc(int liczba_kopia)
{
	liczba_kopia = liczba_kopia++;
    return liczba_kopia;
}

int main()
{
    int liczba = 99;

    cout << zwieksz_wartosc(liczba) << endl;

    return 0;
}

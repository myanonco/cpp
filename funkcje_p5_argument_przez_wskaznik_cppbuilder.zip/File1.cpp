#include <iostream>
#include <conio.h>
using namespace std;
#pragma hdrstop
#pragma argsused

#ifdef _WIN32
#include <tchar.h>
#else
  typedef char _TCHAR;
  #define _tmain main
#endif

#include <stdio.h>
void podwoj_wymiary(int *dl, int *szer, int *wys)
{
    *dl = *dl * 2;
    *szer = *szer * 2;
    *wys = *wys * 2;
}

int _tmain(int argc, _TCHAR* argv[]) 
{
    // inicjalizacja zmiennych
    int dlugosc = 10;
    int szerokosc = 20;
    int wysokosc = 30;

    // wskazniki
    int *wsk_dlugosc = &dlugosc;
    int *wsk_szerokosc = &szerokosc;
    int *wsk_wysokosc = &wysokosc;

    // wywolanie funkcji
    podwoj_wymiary(wsk_dlugosc, wsk_szerokosc, wsk_wysokosc);

    // wyswietlenie nowych wartosci
    cout << "Dlugosc : " << dlugosc << endl;
    cout << "Szerokosc : " << szerokosc << endl;
    cout << "Wysokosc : " << wysokosc << endl;

    getch();
	return 0;
}

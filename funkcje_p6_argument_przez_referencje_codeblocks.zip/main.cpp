#include <iostream>
#include <conio.h>
using namespace std;

void podwoj_wymiary(int &dl, int &szer, int &wys)
{
    dl = dl * 2;
    szer = szer * 2;
    wys = wys * 2;
    cout << "Adres dl : " << &dl << ", adres zm. szer : " << &szer << ", adres zm. wys : " << &wys << endl;
}

int main()
{
    int dlugosc = 10;
    int szerokosc = 20;
    int wysokosc = 30;

    cout << "Adres zm. dlugosc : " << &dlugosc << ", adres zm. szerokosc : " << &szerokosc << ", adres zm. wysokosc : " << &wysokosc << endl;
    podwoj_wymiary(dlugosc, szerokosc, wysokosc);


    // wyswietlenie nowych wartosci
    cout << "Dlugosc : " << dlugosc << ", szerokosc : " << szerokosc << ", wysokosc : " << wysokosc << endl;

    getch();
    return 0;
}

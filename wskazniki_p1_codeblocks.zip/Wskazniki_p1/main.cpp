#include <iostream>

using namespace std;

int main()
{
    int liczba = 100;
    int *wsk_liczba;
    wsk_liczba = &liczba;
    cout << wsk_liczba << endl;
    cout << *wsk_liczba << endl;
    return 0;
}
